# FocusGuard Native — Etapa 1 (prueba de la cadena completa)

Esto NO es todavía la app de bloqueo. Es el experimento mínimo para confirmar
que puedes compilar en la nube e instalar en tu iPhone 13 sin tener una Mac.
Si esto funciona, la Etapa 2 agrega el permiso de Screen Time y ahí veremos
si Apple lo autoriza con una cuenta gratis o si hace falta pagar los
$99/año del Apple Developer Program.

## PARTE 1 — Subir el proyecto a GitHub (en tu laptop)

1. Ve a tu cuenta de GitHub (la misma que usaste para el sitio de la PWA).
2. Crea un repositorio nuevo, por ejemplo `focusguard-native`. Puede ser público o privado — ambos tienen minutos gratis de Actions.
3. Sube **todo el contenido de esta carpeta** tal cual (incluida la carpeta oculta `.github/` con el archivo `workflows/build.yml` adentro, y `Sources/`). Si "Upload files" no te deja subir carpetas ocultas fácil, usa la opción "uploading an existing file" y arrastra la carpeta `focusguard-native` completa a la ventana — GitHub respeta la estructura de carpetas al arrastrar.
4. Confirma el commit.

## PARTE 2 — Ver que compile

1. En tu repo, ve a la pestaña **"Actions"**.
2. Debería aparecer un workflow corriendo llamado **"Build unsigned IPA"** (se dispara solo al subir los archivos).
3. Espera unos 5-10 minutos. Si el círculo se pone ✅ verde, compiló bien.
4. Si sale ❌ rojo: entra al workflow, abre el paso que falló, y **cópiame el texto del error** — lo resolvemos juntos, es normal que la primera vuelta necesite un ajuste.
5. Con ✅ verde: abajo del todo de esa página de ejecución hay una sección **"Artifacts"** con un archivo `FocusGuardNative-ipa`. Descárgalo (es un .zip que trae adentro el `.ipa`).

## PARTE 3 — Instalar AltServer en tu laptop (Windows)

1. Descarga AltServer para Windows desde **altstore.io** (busca "AltServer Windows" — es gratis, de un desarrollador independiente conocido, no de Apple).
2. Instálalo. Durante la instalación te va a pedir los drivers de Apple para USB — si no tienes iTunes o la app "Apple Devices" instalada, AltServer te ofrece instalarlos él mismo. Acepta.
3. Conecta tu iPhone 13 a la laptop con el cable. Desbloquéalo y si aparece "¿Confiar en esta computadora?", toca **Confiar**.
4. Abre AltServer (queda como un ícono en la bandeja del sistema, junto al reloj de Windows). Ahí:
   - **Account → Sign in** con tu Apple ID (el mismo de siempre, el gratuito alcanza).
   - Verifica que tu iPhone aparezca listado en el menú de AltServer.

## PARTE 4 — Instalar el .ipa en tu iPhone

1. Descomprime el .zip que bajaste de GitHub Actions — adentro está `FocusGuardNative.ipa`.
2. En el ícono de AltServer (bandeja del sistema) → clic derecho → **"Install AltStore" → tu iPhone** (esto instala primero la app AltStore en tu teléfono, es un paso único).
3. En tu iPhone, ve a **Ajustes → General → VPN y Gestión de Dispositivos** y confía en el perfil de tu Apple ID que acaba de aparecer.
4. Abre la app **AltStore** en tu iPhone (ícono nuevo). Ve a la pestaña **"My Apps" → botón +** → y selecciona el archivo `.ipa` (esto se hace arrastrando el .ipa a la ventana de AltServer en la laptop, o usando "Apps → Install .ipa" desde el menú de AltServer con el iPhone conectado — la opción exacta puede variar un poco según la versión, si no la encuentras dime qué ves y te guío).
5. Espera un minuto — AltServer firma el .ipa con tu Apple ID y lo manda al teléfono.
6. Verás el ícono de **FocusGuard** aparecer en tu pantalla de inicio, como cualquier app.

## Si algo falla

- **"Aplicación no confiable"** al abrirla: repite el paso de confiar en el perfil (Ajustes → General → VPN y Gestión de Dispositivos).
- **AltServer no ve el iPhone**: revisa que iTunes/Apple Devices esté instalado y que el cable sea de datos (no solo de carga).
- **La app deja de abrir después de 7 días**: es normal con Apple ID gratis — AltServer la vuelve a firmar sola si tu iPhone está en la misma red WiFi que la laptop de vez en cuando, o puedes forzarlo conectando el cable y usando "Refresh" en AltStore.
- **Error de compilación en GitHub Actions**: cópiame el log completo del paso que falló.

## Qué sigue (Etapa 2)

Si llegaste hasta acá y la app abrió en tu iPhone: la cadena completa funciona.
El siguiente paso es agregarle el permiso `com.apple.developer.family-controls`
(el que da acceso real a Screen Time para poder bloquear apps/webs) y pedirle
autorización al sistema desde la app. Ahí es donde vamos a descubrir si Apple
lo permite con tu cuenta gratis o si hace falta el Developer Program pagado
($99/año) — te aviso en cuanto lo intentemos.
